from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.template import Context
from django.template.loader import get_template


def test(request):
        return HttpResponse("This is login page ")

def loginuser(request):
            if request.method == 'POST':
                username = request.POST['username']
                password = request.POST['password']
                user = authenticate(request, username = username, password = password)
                if user is not None:
                    user = login(request, user)
                    messages.success(request, f' welcome {username} !!')
                    return redirect('details')
            else:
                messages.info(request, f'account done not exit plz sign in')
        
            return render(request, 'login.html')
    