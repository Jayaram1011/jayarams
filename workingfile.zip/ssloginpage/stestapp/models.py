from django.contrib.auth.models import User
from django.db import models

# class Details(models.Model):
#     id = models.IntegerField(primary_key=True,unique=True)
#     username = models.CharField(max_length=100,null=False)
#     password =models.CharField(max_length=100,null=False)

class History(models.Model):
    user_id = models.ForeignKey(User,on_delete=models.CASCADE)
    timestamp = models.DateTimeField()