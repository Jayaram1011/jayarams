
import datetime

from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.shortcuts import redirect, render
from stestapp.models import History


def base(request):
    return HttpResponse('This is testing or landing page')

def loginuser(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        print(username,password)
        try:
            user = User.objects.get(username=username)
            print('Username and password are correct')
        except:
            print("User name not exist")
        user = authenticate(request,username=username,password=password)
        print(user)
        if user is not None:
            login(request,user)
            current_time = datetime.datetime.now()
            History.objects.create(user_id=request.user,login_date_time=current_time)
            return redirect('details')
        else:
            print("username ,password incorrect")
        
    return render(request,'login.html')

def details(request):
    username_data = request.user.username
    userid = User.objects.values().filter(username=username_data)
    user_id = (list(userid)[0]['id'])
    details = History.objects.all().filter(user_id = user_id)
    return render(request,'details.html',{'message':details,'username_data':username_data,'userid':user_id})
    
    