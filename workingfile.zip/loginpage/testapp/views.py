
import datetime

from django.contrib.auth import login
from django.http import HttpResponse
from django.shortcuts import redirect, render
from testapp.models import Loginhistory, user_details


def base(request):
    return HttpResponse('This is testing or landing page')

def login_user(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        print(username,password)
        try:
            user_obj = user_details.objects.get(username=username,password=password)
            print('Username and password are correct')
        except:
            print("Incorrect username or password")
        else:
            current_time = datetime.datetime.now()
            print(user_obj.id)
            print(type(user_obj.id))
            print(current_time)
            Loginhistory.objects.create(user_id =user_obj,timestamp=current_time)
            print('executed')
            print(username)
            return redirect('details',user_obj.id)
    return render(request,'login.html')

def details(request,pk):
    data = Loginhistory.objects.all().filter(user_id =pk)
    user = list(user_details.objects.values().filter(id=pk))
    user = user[0]['username']
    return render(request,'details.html',{'message':data,'user':user,'user_id':pk})