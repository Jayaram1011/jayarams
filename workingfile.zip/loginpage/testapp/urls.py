from django.urls import path
from testapp import views

urlpatterns =[
    path('',views.base,name='base'),
    path('login_user/',views.login_user,name='login_user'),
    path('details/<int:pk>/',views.details,name='details')
]
