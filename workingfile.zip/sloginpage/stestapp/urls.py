from django.urls import path
from stestapp import views

urlpatterns =[
    path('',views.base,name='base'),
    path('loginuser/',views.loginuser,name='loginuser'),
    path('details/',views.details,name='details'),
    path('logout/',views.logout,name='logout')
]
