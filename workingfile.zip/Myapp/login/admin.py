from django.contrib import admin
from .models import loginhistory
# Register your models here.
admin.site.register(loginhistory)