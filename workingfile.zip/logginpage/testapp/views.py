import datetime

from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.shortcuts import redirect, render
from testapp.models import Loginhistory, Userdetails


def base(request):
    return HttpResponse('This is testing or landing page')

def loginuser(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        print(username,password)
        try:
            user = Userdetails.objects.get(username=username)
            print('Username and password are correct')
            print(user)
        except:
            print("User name not exist")
        user = authenticate(request,username=username,password=password)
        print(username,password,user)
        print(type(username),type(password))
        
        if user is not None:
            login(request,user)
            current_time = datetime.datetime.now()
            Loginhistory.objects.create(user_id=request.user,login_date_time=current_time)
            return redirect('details')
        else:
            print("username ,password incorrect")
            print(username,password)
        
    return render(request,'login.html')

def details(request):
    username_data = request.user.username
    userid = Userdetails.objects.values().filter(username=username_data)
    user_id = (list(userid)[0]['id'])
    details = Loginhistory.objects.all().filter(user_id = user_id)
    return render(request,'userdetails.html',{'message':details,'username_data':username_data,'userid':user_id})
    
    
