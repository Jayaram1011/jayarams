from django.contrib.auth.models import User
from django.db import models


class Userdetails(models.Model):
    id = models.IntegerField(primary_key=True,unique=True)
    username = models.CharField(max_length=100,null=False)
    password =models.CharField(max_length=100,null=False)

    
class Loginhistory(models.Model):
    user_id = models.ForeignKey(Userdetails,on_delete=models.CASCADE)
    timestamp = models.DateTimeField()