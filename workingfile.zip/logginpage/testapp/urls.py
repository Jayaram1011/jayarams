from django.urls import path
from testapp import views

urlpatterns =[
    path('',views.base,name='base'),
    path('loginuser/',views.loginuser,name='loginuser'),
    path('details/',views.details,name='details')
]