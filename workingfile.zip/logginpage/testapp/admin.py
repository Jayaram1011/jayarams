from django.contrib import admin

from.models import Userdetails,Loginhistory

admin.site.register(Userdetails)
admin.site.register(Loginhistory)
